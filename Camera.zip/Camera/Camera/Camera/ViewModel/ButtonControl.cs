﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Camera
{
    class ButtonControl : INotifyPropertyChanged
    {
        

        private void etap1()
        {
            OnPropertyChanged("Visibility");
        }

        private void etap2()
        {

        }

        public ButtonControl()
        {
            
        }

        public void nextstep(string step)
        {
            if(step == "etap1")
            {
                etap1();
            }
        }

        event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }

        event PropertyChangedEventHandler INotifyPropertyChanged.PropertyChanged
        {
            add
            {
                throw new NotImplementedException();
            }

            remove
            {
                throw new NotImplementedException();
            }
        }
    }
}
