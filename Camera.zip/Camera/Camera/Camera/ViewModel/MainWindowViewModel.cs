﻿using Camera.Model;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using static System.Net.Mime.MediaTypeNames;
namespace Camera.ViewModel
{
    class MainWindowViewModel : ViewModelBase
    {
        #region Fields

        #endregion

        #region Properties
        public string Round { get; set; }

        public bool Kolor01 { get; set; }
        public bool Kolor02 { get; set; }
        public string Kolor03 { get; set; }
        public string Kolor04 { get; set; }
        public string Kolor05 { get; set; }
        public string Kolor06 { get; set; }
        public string Kolor07 { get; set; }
        #endregion 

        #region Commands
        public ICommand Button1Command { get; set; }
        public ICommand Button2Command { get; set; }
        public ICommand Button3Command { get; set; }
        public ICommand Button4Command { get; set; }
        public ICommand Button6Command { get; set; }
        public ICommand Button7Command { get; set; }
        #endregion

        public MainWindowViewModel()
        {
            WebClient client = new WebClient();
            string reply = client.DownloadString("https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/slupsk?unitGroup=metric&include=days%2Ccurrent&key=KE4Y3ZYASSHCLGT8B24VVTGRY&contentType=json");
            Weather weather = JsonConvert.DeserializeObject<Weather>(reply);

        }
        #region Private methods
        public void Property(Brush kolor)
        {

        }

        private void ChangeName(object obj)
        {

        }
        #endregion

        #region Classes
        public class Weather
        {
            public double latitude { get; set; }
            public double longitude { get; set; }
            public string resolvedAddress { get; set; }
            public bool xxxx { get; set; }
            public IList<string> Roles { get; set; }
        }
        #endregion
    }
}
