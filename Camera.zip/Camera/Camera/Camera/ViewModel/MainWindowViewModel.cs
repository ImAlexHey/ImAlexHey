﻿using Camera.Model;
using Emgu.CV.BgSegm;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using static System.Net.Mime.MediaTypeNames;

namespace Camera.ViewModel
{
    class MainWindowViewModel : ViewModelBase
    {
        #region Fields
        public RelayCommand ChangeNameCommand;
        #endregion

        #region Properties
        public string Round { get; set; }
        #endregion

        #region Properties
        public string Kolor01 { get; set; }
        #endregion 

        #region Commands
        public ICommand Button1Command { get; set; }
        #endregion

        #region Commands
        public ICommand Button2Command { get; set; }
        #endregion

        #region Commands
        public ICommand Button3Command { get; set; }
        #endregion

        #region Commands
        public ICommand Button4Command { get; set; }
        #endregion

        #region Commands
        public ICommand Button5Command { get; set; }
        #endregion

        #region Commands
        public ICommand Button6Command { get; set; }
        #endregion

        #region Commands
        public ICommand Button7Command { get; set; }
        #endregion
        public MainWindowViewModel()
        {
            Round = "Red";
            Kolor01 = "Red";
            Button1Command = new RelayCommand(new Action<object>(ChangeName));
        }


        #region Private methods

        bool runda;
        public void Property(string kolor)
        {
            kolor = "Blue";
            OnPropertyChanged(nameof(kolor));
            //if (runda == false)
            //{
            //    kolor = "Blue";
            //    OnPropertyChanged(nameof(kolor));
            //    runda = true;
            //}
            //else if (runda == true)
            //{
            //    kolor = "Red";
            //    OnPropertyChanged(nameof(kolor));
            //    runda = false;
            //}
        }

        private void ChangeName(object obj)
        {
            Property(Kolor01);
            //if (runda == false)
            //{
            //    Kolor01 = "Red";
            //    OnPropertyChanged(nameof(Kolor01));
            //    Round = "Green round";
            //    OnPropertyChanged(nameof (Round));
            //    runda = true;
            //}
            //else if (runda == true)
            //{
            //    Kolor01 = "Blue";
            //    OnPropertyChanged(nameof(Kolor01));
            //    Round = "Red round";
            //    OnPropertyChanged(nameof (Round));
            //    runda = false;
            //}

        }
        #endregion
    }
}
