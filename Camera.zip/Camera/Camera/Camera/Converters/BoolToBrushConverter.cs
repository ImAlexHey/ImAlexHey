﻿using Camera.Model;
using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace Camera.Converters
{
    public class BoolToBrushConverter : IValueConverter
    {

        #region Fields

        #endregion

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if ((bool)value)
            {
                return Brushes.Blue;
            }
            else
            {
                return Brushes.White;
            }
            return 0;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();           
        }
    }
}
