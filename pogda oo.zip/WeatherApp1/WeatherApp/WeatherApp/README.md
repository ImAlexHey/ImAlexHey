# WeatherApp

https://www.visualcrossing.com/resources/documentation/weather-api/defining-icon-set-in-the-weather-api/
