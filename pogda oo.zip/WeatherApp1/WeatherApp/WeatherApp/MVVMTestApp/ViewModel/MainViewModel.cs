﻿using Camera.Model;
using MVVMTestApp.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media.Animation;
using MVVMTestApp.View.UserControls;

namespace MVVMTestApp.ViewModel
{
    class MainViewModel : ViewModelBase
    {
        #region Fields
        RelayCommand commands;
        #endregion


        #region Properties
        public string Address { get; set; }
        public string Timezone { get; set; }
        public string ResolvedAddress { get; set; }
        public float Temp { get; set; }
        public string OvDescription { get; set; }
        public RootObject Weather { get; set; } = null;
        #endregion


        #region Commands
        public ICommand Loaded { get; set; }
        #endregion

        #region Constructor
        public MainViewModel()
        {
            Loaded = new RelayCommand(new Action<object>(LoadedV));
        }


        #endregion

        #region Private methods
        private void LoadedV(object obj)
        {
            try
            {
                WebClient client = new WebClient();
                string reply = client.DownloadString("https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/S%C5%82upsk3?unitGroup=metric&include=days&key=STYM2WDSNM3Y34EAYESBU8AQ6&contentType=json");
                Weather = JsonConvert.DeserializeObject<RootObject>(reply);
                //Weather.Days.RemoveAt(0);
                RaisePropertyChanged(nameof(Weather));
            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message, "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
            }
            #endregion
        }
    }
}
