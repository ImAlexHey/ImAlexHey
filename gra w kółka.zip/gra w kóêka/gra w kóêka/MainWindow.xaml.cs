﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
namespace gra_w_kółka
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int t1 = 0;
        int t2 = 0;
        int t3 = 0;
        int t4 = 0;
        int t5 = 0;
        int t6 = 0;
        int t7 = 0;
        string gracz;
        String[,] B = new String[20, 20];
        bool tura;
        void Label1(System.Windows.Controls.Label u, int x, int y)
        {
            if (tura == false)
            {
                tura = true;
                u.Background = new SolidColorBrush(Colors.CadetBlue);
                LABELNG.Content = "Tura gracza czerwonego";
                B[x, y] = "X";
                gracz = "zielony";
            }
            else if (tura == true)
            {
                tura = false;
                u.Background = new SolidColorBrush(Colors.IndianRed);
                LABELNG.Content = "Tura gracza zielonego";
                B[x, y] = "Y";
                gracz = "czerwony";
            }
            if
                (
                      B[x, y] == B[x, y + 1] && B[x, y] == B[x, y + 2] && B[x, y] == B[x, y + 3] // do góry
                   || B[x, y] == B[x - 1, y] && B[x, y] == B[x - 2, y] && B[x, y] == B[x - 3, y] // do prawej
                   || B[x, y] == B[x + 1, y] && B[x, y] == B[x + 2, y] && B[x, y] == B[x + 3, y] // do lewej
                   || B[x, y] == B[x - 1, y] && B[x, y] == B[x + 1, y] && B[x, y] == B[x + 2, y] // bok 1
                   || B[x, y] == B[x + 1, y] && B[x, y] == B[x - 1, y] && B[x, y] == B[x - 2, y] // bok 2
                   || B[x, y] == B[x - 1, y + 1] && B[x, y] == B[x - 2, y + 2] && B[x, y] == B[x - 3, y + 3] // skos do prawej od dołu
                   || B[x, y] == B[x - 1, y - 1] && B[x, y] == B[x - 2, y - 2] && B[x, y] == B[x - 3, y - 3] // skos do prawej od góry
                   || B[x, y] == B[x - 1, y - 1] && B[x, y] == B[x + 1, y + 1] && B[x, y] == B[x + 2, y + 2]
                   || B[x, y] == B[x + 1, y + 1] && B[x, y] == B[x - 1, y - 1] && B[x, y] == B[x - 2, y - 2]
                   || B[x, y] == B[x + 1, y + 1] && B[x, y] == B[x + 2, y + 2] && B[x, y] == B[x + 3, y + 3] // skos do lewej od dołu
                   || B[x, y] == B[x + 1, y - 1] && B[x, y] == B[x + 2, y - 2] && B[x, y] == B[x + 3, y - 3] // skos do lewej od góry
                   || B[x, y] == B[x + 1, y - 1] && B[x, y] == B[x - 1, y + 1] && B[x, y] == B[x - 2, y + 2]
                   || B[x, y] == B[x + 2, y - 2] && B[x, y] == B[x + 1, y - 1] && B[x, y] == B[x - 1, y + 1]
                )
                LABELNG.Content = "Wygrał gracz " + gracz;
            //B1.IsEnabled = false;
            //B2.IsEnabled = false;
            //B3.IsEnabled = false;
            //B4.IsEnabled = false;
            //B5.IsEnabled = false;
            //B6.IsEnabled = false;
            //B7.IsEnabled = false;
        }
        void Button1()
        {
            t1++;
            if (t1 == 1)
            {
                Label1(LABEL07, 7, 7);
            }
            else if (t1 == 2)
            {
                Label1(LABEL06, 7, 6);
            }
            else if (t1 == 3)
            {
                Label1(LABEL05, 7, 5);
            }
            else if (t1 == 4)
            {
                Label1(LABEL04, 7, 4);
            }
            else if (t1 == 5)
            {
                Label1(LABEL03, 7, 3);
            }
            else if (t1 == 6)
            {
                Label1(LABEL02, 7, 2);
            }
            else if (t1 == 7)
            {
                Label1(LABEL01, 7, 1);
            }
        }
        void Button2()
        {
            t2++;
            if (t2 == 1)
            {
                Label1(LABEL17, 8, 7);
            }
            else if (t2 == 2)
            {
                Label1(LABEL16, 8, 6);
            }
            else if (t2 == 3)
            {
                Label1(LABEL15, 8, 5);
            }
            else if (t2 == 4)
            {
                Label1(LABEL14, 8, 4);
            }
            else if (t2 == 5)
            {
                Label1(LABEL13, 8, 3);
            }
            else if (t2 == 6)
            {
                Label1(LABEL12, 8, 2);
            }
            else if (t2 == 7)
            {
                Label1(LABEL11, 8, 1);
            }
        }
        void Button3()
        {
            t3++;
            if (t3 == 1)
            {
                Label1(LABEL27, 9, 7);
            }
            else if (t3 == 2)
            {
                Label1(LABEL26, 9, 6);
            }
            else if (t3 == 3)
            {
                Label1(LABEL25, 9, 5);
            }
            else if (t3 == 4)
            {
                Label1(LABEL24, 9, 4);
            }
            else if (t3 == 5)
            {
                Label1(LABEL23, 9, 3);
            }
            else if (t3 == 6)
            {
                Label1(LABEL22, 9, 2);
            }
            else if (t3 == 7)
            {
                Label1(LABEL21, 9, 1);
            }
        }
        void Button4()
        {
            t4++;
            if (t4 == 1)
            {
                Label1(LABEL37, 10, 7);
            }
            else if (t4 == 2)
            {
                Label1(LABEL36, 10, 6);
            }
            else if (t4 == 3)
            {
                Label1(LABEL35, 10, 5);
            }
            else if (t4 == 4)
            {
                Label1(LABEL34, 10, 4);
            }
            else if (t4 == 5)
            {
                Label1(LABEL33, 10, 3);
            }
            else if (t4 == 6)
            {
                Label1(LABEL32, 10, 2);
            }
            else if (t4 == 7)
            {
                Label1(LABEL31, 10, 1);
            }
        }
        void Button5()
        {

            t5++;
            if (t5 == 1)
            {
                Label1(LABEL47, 11, 7);
            }
            else if (t5 == 2)
            {
                Label1(LABEL46, 11, 6);
            }
            else if (t5 == 3)
            {
                Label1(LABEL45, 11, 5);
            }
            else if (t5 == 4)
            {
                Label1(LABEL44, 11, 4);
            }
            else if (t5 == 5)
            {
                Label1(LABEL43, 11, 3);
            }
            else if (t5 == 6)
            {
                Label1(LABEL42, 11, 2);
            }
            else if (t5 == 7)
            {
                Label1(LABEL41, 11, 1);
            }
        }
        void Button6()
        {

            t6++;
            if (t6 == 1)
            {
                Label1(LABEL57, 12, 7);
            }
            else if (t6 == 2)
            {
                Label1(LABEL56, 12, 6);
            }
            else if (t6 == 3)
            {
                Label1(LABEL55, 12, 5);
            }
            else if (t6 == 4)
            {
                Label1(LABEL54, 12, 4);
            }
            else if (t6 == 5)
            {
                Label1(LABEL53, 12, 3);
            }
            else if (t6 == 6)
            {
                Label1(LABEL52, 12, 2);
            }
            else if (t6 == 7)
            {
                Label1(LABEL51, 12, 1);
            }
        }
        void Button7()
        {

            t7++;
            if (t7 == 1)
            {
                Label1(LABEL67 ,13 ,7);
            }
            else if (t7 == 2)
            {
                Label1(LABEL66, 13, 6);
            }
            else if (t7 == 3)
            {
                Label1(LABEL65, 13, 5);
            }
            else if (t7 == 4)
            {
                Label1(LABEL64, 13, 4);
            }
            else if (t7 == 5)
            {
                Label1(LABEL63, 13, 3);
            }
            else if (t7 == 6)
            {
                Label1(LABEL62, 13, 2);
            }
            else if (t7 == 7)
            {
                Label1(LABEL61, 13, 1);
            }
        }
        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            Button1();
        }
        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            Button2();
        }
        private void Button3_Click(object sender, RoutedEventArgs e)
        {
            Button3();
        }
        private void Button4_Click(object sender, RoutedEventArgs e)
        {
            Button4();
        }
        private void Button5_Click(object sender, RoutedEventArgs e)
        {
            Button5();
        }
        private void Button6_Click(object sender, RoutedEventArgs e)
        {
            Button6();
        }

        private void Button7_Click(object sender, RoutedEventArgs e)
        {
            Button7();
        }
        private void ButtonNG_Click(object sender, RoutedEventArgs e)
        {
            LABELNG.Content = "Tura gracza zielonego";
            tura = false;

            t1 = 0;
            t2 = 0;
            t3 = 0;
            t4 = 0;
            t5 = 0;
            t6 = 0;
            t7 = 0;

            B1.IsEnabled = true;
            B2.IsEnabled = true;
            B3.IsEnabled = true;
            B4.IsEnabled = true;
            B5.IsEnabled = true;
            B6.IsEnabled = true;
            B7.IsEnabled = true;

        }
    }
}
