﻿using MVVMTestApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVMTestApp.ViewModel
{
    class MainViewModel : ViewModelBase
    {
        #region Fields
        private ViewModelBase currentScreen;
        #endregion

        #region Properties
        public ViewModelBase CurrentScreen
        {
            get => currentScreen;
            set
            {
                currentScreen = value;
                RaisePropertyChanged("CurrentScreen");
            }
        }
        #endregion

        #region Commands
        public RelayCommand Next { get; set; }
        public RelayCommand Back { get; set; }
        #endregion

        #region Constructor
        public MainViewModel()
        {
            Next = new RelayCommand(SetNextScreen);
            Back = new RelayCommand(SetPreviousScreen);
            CurrentScreen = new Screens.Screen1ViewModel();
        }
        #endregion

        #region Private methods
        private void SetNextScreen()
        {
            if (CurrentScreen.GetType() == typeof(Screens.Screen1ViewModel))
            {
                CurrentScreen = new Screens.Screen2ViewModel();
                return;
            }

            if (CurrentScreen.GetType() == typeof(Screens.Screen2ViewModel))
            {
                CurrentScreen = new Screens.Screen3ViewModel();
                return;
            }
        }

        private void SetPreviousScreen()
        {
            if (CurrentScreen.GetType() == typeof(Screens.Screen2ViewModel))
            {
                CurrentScreen = new Screens.Screen1ViewModel();
                return;
            }

            if (CurrentScreen.GetType() == typeof(Screens.Screen3ViewModel))
            {
                CurrentScreen = new Screens.Screen2ViewModel();
                return;
            }
        }
        #endregion
    }
}
