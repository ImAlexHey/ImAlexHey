﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVMTestApp.ViewModel.Screens
{
    class Screen2ViewModel : ViewModelBase
    {
        public string Text { get; set; }

        public Screen2ViewModel()
        {
            Text = "Drugi ekran";
        }
    }
}
