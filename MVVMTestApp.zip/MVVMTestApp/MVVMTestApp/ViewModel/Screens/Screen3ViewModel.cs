﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVMTestApp.ViewModel.Screens
{
    class Screen3ViewModel : ViewModelBase
    {
        public string Text { get; set; }

        public Screen3ViewModel()
        {
            Text = "Trzeci ekran";
        }
    }
}
