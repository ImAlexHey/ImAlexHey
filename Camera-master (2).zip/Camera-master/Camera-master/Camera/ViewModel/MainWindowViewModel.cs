﻿using Camera.Model;
using Emgu.CV.BgSegm;
using Emgu.CV.DepthAI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using static System.Net.Mime.MediaTypeNames;
namespace Camera.ViewModel
{
    class MainWindowViewModel : ViewModelBase
    {
        #region Fields
        public RelayCommand ChangeNameCommand;
        public Player player = new Player("0");
        #endregion

       
        #region Properties
        public string Round { get; set; }

        public int Kolor01 { get; set; }
        public int Kolor02 { get; set; }
        public int Kolor03 { get; set; }
        public int Kolor04 { get; set; }
        public int Kolor05 { get; set; }
        public int Kolor06 { get; set; }
        public int Kolor07 { get; set; }

        public int Kolor11 { get; set; }
        public int Kolor12 { get; set; }
        public int Kolor13 { get; set; }
        public int Kolor14 { get; set; }
        public int Kolor15 { get; set; }
        public int Kolor16 { get; set; }
        public int Kolor17 { get; set; }

        public int Kolor21 { get; set; }
        public int Kolor31 { get; set; }
        public int Kolor41 { get; set; }
        public int Kolor51 { get; set; }
        public int Kolor61 { get; set; }
        #endregion 

        #region Commands
        public ICommand Button1Command { get; set; }
        public ICommand Button2Command { get; set; }
        public ICommand Button3Command { get; set; }
        public ICommand Button4Command { get; set; }
        public ICommand Button5Command { get; set; }
        public ICommand Button6Command { get; set; }
        public ICommand Button7Command { get; set; }
        #endregion

        string[,] B = new string[10, 10];
        public MainWindowViewModel()
        {
            Round = "Green round";

            Button1Command = new RelayCommand(new Action<object>(Button1));
            Button2Command = new RelayCommand(new Action<object>(Button2));
        }
        #region Private methods
        bool tura = true;
        int t1 = 0;
        int t2 = 0;
        void RoundTextLabel()
        {
            if (tura == false)
            {
                Round = "Red round";
            }
            else if (tura == true)
            {
                Round = "Green round";
            }
            OnPropertyChanged(nameof(Round));
        }




        void Button1(object obj)
        {
            if(t1 == 0)
            {

                if (tura == false)
                {
                    Kolor07 = 1;
                    tura = true;
                    B[7, 7] = "X";
                }
                else if (tura == true)
                {
                    Kolor07 = 2;
                    tura = false;
                    B[7, 7] = "Y";
                }

                OnPropertyChanged(nameof(Kolor07));
                RoundTextLabel();
                t1++;
            }
            else if (t1 == 1)
            {
                if (tura == false)
                {
                    Kolor06 = 1;
                    tura = true;
                    B[7, 6] = "X";
                }
                else if (tura == true)
                {
                    Kolor06 = 2;
                    tura = false;
                    B[7, 6] = "X";
                }
                OnPropertyChanged(nameof(Kolor06));
                RoundTextLabel();
                t1++;
            }
            else if (t1 == 2)
            {
                if (tura == false)
                {
                    Kolor05 = 1;
                    tura = true;
                    B[7, 5] = "X";
                }
                else if (tura == true)
                {
                    Kolor05 = 2;
                    tura = false;
                    B[7, 5] = "X";
                }
                OnPropertyChanged(nameof(Kolor05));
                RoundTextLabel();
                t1++;
            }
            else if (t1 == 3)
            {
                if (tura == false)
                {
                    Kolor04 = 1;
                    tura = true;
                    B[7, 4] = "X";
                }
                else if (tura == true)
                {
                    Kolor04 = 2;
                    tura = false;
                    B[7, 4] = "X";
                }
                OnPropertyChanged(nameof(Kolor04));
                RoundTextLabel();
                t1++;
            }
            else if (t1 == 4)
            {
                if (tura == false)
                {
                    Kolor03 = 1;
                    tura = true;
                    B[7, 4] = "X";
                }
                else if (tura == true)
                {
                    Kolor03 = 2;
                    tura = false;
                    B[7, 4] = "X";
                }
                OnPropertyChanged(nameof(Kolor03));
                RoundTextLabel();
                t1++;
            }
            else if (t1 == 5)
            {
                if (tura == false)
                {
                    Kolor02 = 1;
                    tura = true;
                    B[7, 2] = "X";
                }
                else if (tura == true)
                {
                    Kolor02 = 2;
                    tura = false;
                    B[7, 2] = "X";
                }
                OnPropertyChanged(nameof(Kolor02));
                RoundTextLabel();
                t1++;
            }
            else if (t1 == 6)
            {
                if (tura == false)
                {
                    Kolor01 = 1;
                    tura = true;
                    B[7, 1] = "X";
                }
                else if (tura == true)
                {
                    Kolor01 = 2;
                    tura = false;
                    B[7, 1] = "X";
                }
                OnPropertyChanged(nameof(Kolor01));
                RoundTextLabel();
                t1++;
            }
        }
        void Button2(object obj)
        {
            if (t2 == 0)
            {

                if (tura == false)
                {
                    Kolor17 = 1;
                    tura = true;
                    B[7, 7] = "X";
                }
                else if (tura == true)
                {
                    Kolor17 = 2;
                    tura = false;
                    B[7, 7] = "Y";
                }

                OnPropertyChanged(nameof(Kolor17));
                RoundTextLabel();
                t2++;
            }
            else if (t1 == 1)
            {
                if (tura == false)
                {
                    Kolor16 = 1;
                    tura = true;
                }
                else if (tura == true)
                {
                    Kolor16 = 2;
                    tura = false;
                }
                OnPropertyChanged(nameof(Kolor16));
                RoundTextLabel();
                t2++;
            }
            else if (t2 == 2)
            {
                if (tura == false)
                {
                    Kolor15 = 1;
                    tura = true;
                }
                else if (tura == true)
                {
                    Kolor15 = 2;
                    tura = false;
                }
                OnPropertyChanged(nameof(Kolor15));
                RoundTextLabel();
                t2++;
            }
            else if (t2 == 3)
            {
                if (tura == false)
                {
                    Kolor14 = 1;
                    tura = true;
                }
                else if (tura == true)
                {
                    Kolor04 = 2;
                    tura = false;
                }
                OnPropertyChanged(nameof(Kolor14));
                RoundTextLabel();
                t2++;
            }
            else if (t2 == 4)
            {
                if (tura == false)
                {
                    Kolor13 = 1;
                    tura = true;
                }
                else if (tura == true)
                {
                    Kolor13 = 2;
                    tura = false;
                }
                OnPropertyChanged(nameof(Kolor13));
                RoundTextLabel();
                t2++;
            }
            else if (t2 == 5)
            {
                if (tura == false)
                {
                    Kolor12 = 1;
                    tura = true;
                }
                else if (tura == true)
                {
                    Kolor12 = 2;
                    tura = false;
                }
                OnPropertyChanged(nameof(Kolor12));
                RoundTextLabel();
                t2++;
            }
            else if (t2 == 6)
            {
                if (tura == false)
                {
                    Kolor11 = 1;
                    tura = true;
                }
                else if (tura == true)
                {
                    Kolor11 = 2;
                    tura = false;
                }
                OnPropertyChanged(nameof(Kolor11));
                RoundTextLabel();
                t2++;
            }
        }
        #endregion
    }
}
