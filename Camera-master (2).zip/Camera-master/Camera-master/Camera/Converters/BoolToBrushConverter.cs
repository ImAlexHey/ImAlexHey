﻿using Camera.Model;
using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace Camera.Converters
{
    public class BoolToBrushConverter : IValueConverter
    {
        #region Fields
        public Player player = new Player("0");
        #endregion

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // Convert the integer to a brush using a switch statement
            switch ((int)value)
            {
                case 0:
                    return Brushes.White;
                case 1:
                    return Brushes.IndianRed;
                case 2:
                    return Brushes.CadetBlue;
                default:
                    return Brushes.White;
            }
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}