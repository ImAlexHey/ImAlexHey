﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
namespace tic_tac_toe
{
    public partial class MainWindow : Window
    {
        string[,]B = new string[3, 3];        
        public MainWindow()
        {
            InitializeComponent();
            Board();
        }
        void Board()
        {
            B[0, 0] = "1";
            B[1, 0] = "2";
            B[2, 0] = "3";
            B[0, 1] = "4";
            B[1, 1] = "5";
            B[2, 1] = "6";
            B[0, 2] = "7";
            B[1, 2] = "8";
            B[2, 2] = "9";
        }
        void Enable(bool enable)
        {
            But1.IsEnabled = enable;
            But2.IsEnabled = enable;
            But3.IsEnabled = enable;
            But4.IsEnabled = enable;
            But5.IsEnabled = enable;
            But6.IsEnabled = enable;
            But7.IsEnabled = enable;
            But8.IsEnabled = enable;
            But9.IsEnabled = enable;
        }
        void Clean()
        {
            But1.Content = "";
            But2.Content = "";
            But3.Content = "";
            But4.Content = "";
            But5.Content = "";
            But6.Content = "";
            But7.Content = "";
            But8.Content = "";
            But9.Content = "";
        }
        string content;
        bool tura;
        string Tura(int x,int y)
        {
            if (tura == false)
            {

                label.Content = "Tura gracza O";
                tura = true;               
                content = "X";
                B[x, y] = "X";              
            }
            else if(tura == true)
            {
                label.Content = "Tura gracza X";
                tura = false;             
                content = "O";
                B[x, y] = "O";               
            }
            return content;
        }
        void koniec()
        {
            if 
            (           
                B[0,0] == B[1,0] && B[0,0] == B[2,0] //1 poziom d
              ||B[0,1] == B[1,1] && B[0,1] == B[2,1] //2 poziom d
              ||B[0,2] == B[1,2] && B[0,2] == B[2,2] //3 poziom d

              ||B[0,1] == B[0,0] && B[0,1] == B[0,2] //1 kolumna d
              ||B[1,0] == B[1,1] && B[1,0] == B[1,2] //2 kolumna d
              ||B[2,0] == B[2,1] && B[2,0] == B[2,2] //3 kolumna d

              ||B[0,0] == B[1,1] && B[0,0] == B[2,2] //skos lewy d
              ||B[2,0] == B[1,1] && B[2,0] == B[0,2] //skos prawy d
            )
            {
              
              Enable(false);
                label.Content = "Wygrał gracz " + content;
            }
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            But1.Content = Tura(0,0);
            But1.IsEnabled = false;
            koniec();
        }
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            But2.Content = Tura(1,0);
            But2.IsEnabled = false;
            koniec();
        }
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            But3.Content = Tura(2,0);
            But3.IsEnabled = false;
            koniec();
        }
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            But4.Content = Tura(0,1);
            But4.IsEnabled = false;
            koniec();
        }
        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            But5.Content = Tura(1,1);
            But5.IsEnabled = false;
            koniec();
        }
        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            But6.Content = Tura(2,1);
            But6.IsEnabled = false;
            koniec();
        }
        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            But7.Content = Tura(0,2);
            But7.IsEnabled = false;
            koniec();
        }
        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            But8.Content = Tura(1,2);
            But8.IsEnabled = false;
            koniec();
        }
        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            But9.Content = Tura(2,2);
            But9.IsEnabled = false;
            koniec();
        }
        private void Button_Click_NG(object sender, RoutedEventArgs e)
        {
            Enable(true);
            Clean();
            Board();
            label.Content = "Tura gracza X";
        }
    }
}
