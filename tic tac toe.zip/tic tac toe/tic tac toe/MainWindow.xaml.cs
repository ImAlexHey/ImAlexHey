﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
namespace tic_tac_toe
{
    public partial class MainWindow : Window
    {
        bool tura;
        string[,] Board = new string[3, 3];
        public MainWindow()
        {
            InitializeComponent();
        }
        string Tura()
        {
            string content;
            if(tura == false)
            { 
                tura = true;
                label.Content = "Tura gracza O";
                content = "X";
            }
            else
            {
                tura = false;
                label.Content = "tura gracza X";
                content = "O";
            }
            return content;
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            But1.Content = Tura();
            But1.IsEnabled = false;
            //Board[0,0];
        }
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            But2.Content = Tura();
            But2.IsEnabled = false;
        }
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            But3.Content = Tura();
            But3.IsEnabled = false;
        }
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            But4.Content = Tura();
            But4.IsEnabled = false;
        }
        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            But5.Content = Tura();
            But5.IsEnabled = false;
        }
        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            But6.Content = Tura();
            But6.IsEnabled = false;
        }
        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            But7.Content = Tura();
            But7.IsEnabled = false;
        }
        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            But8.Content = Tura();
            But8.IsEnabled = false;
        }
        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            But9.Content = Tura();
            But9.IsEnabled = false;
        }
        private void Button_Click_NG(object sender, RoutedEventArgs e)
        {

        }
    }
}
